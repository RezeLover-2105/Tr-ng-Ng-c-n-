print("*")
print("**")
print("***")
print("****")
